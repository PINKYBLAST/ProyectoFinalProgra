/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectozoo;

/**
 *
 * @author Pepe Le Pew
 */
public class Animal {
    //nombre edad especie habitad #animal alimento horario frecuencia alimento 
    private String nombre, especie, alimento, horario, frecAlimento, habitat;//habitad debe ser cambiado por un objeto de tipo habitad
    private int edad, id;//id = #animal 

    public Animal(String nombre, String especie, String alimento, String horario, String frecAlimento, String habitat, int edad, int id) {
        this.nombre = nombre;
        this.especie = especie;
        this.alimento = alimento;
        this.horario = horario;
        this.frecAlimento = frecAlimento;
        this.habitat = habitat;
        this.edad = edad;
        this.id = id;
    }
    
    public String gestionAlimentacion(){
        return  "Nombre=" + nombre + "\nAlimento=" + alimento + "\nHorario=" + horario + "\nFrecAlimento=" + frecAlimento ;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getEspecie() {
        return especie;
    }

    public void setEspecie(String especie) {
        this.especie = especie;
    }

    public String getAlimento() {
        return alimento;
    }

    public void setAlimento(String alimento) {
        this.alimento = alimento;
    }

    public String getHorario() {
        return horario;
    }

    public void setHorario(String horario) {
        this.horario = horario;
    }

    public String getFrecAlimento() {
        return frecAlimento;
    }

    public void setFrecAlimento(String frecAlimento) {
        this.frecAlimento = frecAlimento;
    }

    public String getHabitat() {
        return habitat;
    }

    public void setHabitat(String habitat) {
        this.habitat = habitat;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    //Despues debe ser modificada por un obj de tipo habitad
    @Override
    public String toString() {
        return "Animal{" + "nombre=" + nombre + ", especie=" + especie + ", alimento=" + alimento + ", horario=" + horario + ", frecAlimento=" + frecAlimento + ", habitat=" + habitat + ", edad=" + edad + ", id=" + id + '}';
    }
}
