/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package proyectozoo;

import javax.swing.JOptionPane;

/**
 *
 * @author Pepe Le Pew
 */
public class ProyectoZoo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //Previo al menu se requiere todos los elementos de arreglos que se encuentran 
        //En las clases que gestionan los arreglos de objetos como RegistroAnimales
        RegistroAnimales registroAnimales = new RegistroAnimales();

        //menu
        int index = 0;
        do {
            index = Integer.parseInt(JOptionPane.showInputDialog("********** MENU PRINCIPAL **********\n"
                    + "1)REGISTRO DE ANIMALES\n" + "2)REGISTRO DE HABITATS\n" + "3)REGISTRO DE VISITANTES\n"
                    + "4)REGISTRO DE EVENTOS DEL ZOOLOGICO\n" + "5)GESTION DE ALIMENTACION\n" + "6)MAPA\n" + "0)SALIR\n"
                    + "Ingrese el numero de la opcion\n"));

            switch (index) {
                case 1:
                    while (index != 0) {
                        index = Integer.parseInt(JOptionPane.showInputDialog("********** MENU REGISTRO ANIMALES **********\n"
                                + "1)REGISTRAR NUEVO ANIMAL\n" + "2)EDITAR ANIMAL\n" + "3)MOSTRAR ANIMAL\n"
                                + "4)MOSTRAR LISTADO DE TODOS LOS ANIMALES\n" + "5)ELIMINAR ANIMAL\n" + "0)REGRESAR AL MENU PRINCIPAL\n"
                                + "Ingrese el numero de la opcion\n"));
                        switch (index) {
                            case 1:
                                registroAnimales.agregar(new Animal(
                                        JOptionPane.showInputDialog("Ingrese el nombre"),
                                        JOptionPane.showInputDialog("Ingrese la especie"),
                                        JOptionPane.showInputDialog("Ingrese la alimentacion"),
                                        JOptionPane.showInputDialog("Ingrese el horario"),
                                        JOptionPane.showInputDialog("Ingrese la frecuencia de alimentacion"),
                                        JOptionPane.showInputDialog("Ingrese el habitat"),
                                        Integer.parseInt(JOptionPane.showInputDialog("Ingrese la edad")),
                                        Integer.parseInt(JOptionPane.showInputDialog("Ingrese el id"))));
                                break;
                            case 2:
                                while (index != 0) {
                                    index = Integer.parseInt(JOptionPane.showInputDialog("********** MENU EDITAR ANIMAL **********\n"
                                            + "1)EDITAR NOMBREL\n" + "2)EDITAR ESPECIE\n" + "3)EDITAR ALIMENTACION\n" + "4)EDITAR HORARIO\n" + "5)EDITAR FRECUENCIA DE ALIMENTACION\n"
                                            + "6)EDITAR HABITAT\n" + "7)EDITAR EDAD\n" + "8)EDITAR ID\n" + "0)REGRESAR AL MENU ANIMALES\n"
                                            + "Ingrese el numero de la opcion\n"));
                                    int resp = 0;
                                    switch (index) {
                                        case 1:
                                            resp = registroAnimales.modificaNombre(Integer.parseInt(JOptionPane.showInputDialog("Ingrese el id")),
                                                    JOptionPane.showInputDialog("Ingrese el nombre"));
                                            break;
                                        case 2:
                                            resp = registroAnimales.modificaEspecie(Integer.parseInt(JOptionPane.showInputDialog("Ingrese el id")),
                                                    JOptionPane.showInputDialog("Ingrese la especie"));
                                            break;
                                        case 3:
                                            resp = registroAnimales.modificaAlimento(Integer.parseInt(JOptionPane.showInputDialog("Ingrese el id")),
                                                    JOptionPane.showInputDialog("Ingrese la alimentacion"));
                                            break;
                                        case 4:
                                            resp = registroAnimales.modificaHorario(Integer.parseInt(JOptionPane.showInputDialog("Ingrese el id")),
                                                    JOptionPane.showInputDialog("Ingrese el horario"));
                                            break;
                                        case 5:
                                            resp = registroAnimales.modificaFrecAl(Integer.parseInt(JOptionPane.showInputDialog("Ingrese el id")),
                                                    JOptionPane.showInputDialog("Ingrese la frecuencia de alimentacion"));
                                            break;
                                        case 6:
                                            resp = registroAnimales.modificaHabitat(Integer.parseInt(JOptionPane.showInputDialog("Ingrese el id")),
                                                    JOptionPane.showInputDialog("Ingrese el habitat"));
                                            break;
                                        case 7:
                                            resp = registroAnimales.modificaEdad(Integer.parseInt(JOptionPane.showInputDialog("Ingrese el id")),
                                                    Integer.parseInt(JOptionPane.showInputDialog("Ingrese la edad")));
                                            break;
                                        case 8:
                                            resp = registroAnimales.modificaId(Integer.parseInt(JOptionPane.showInputDialog("Ingrese el id")),
                                                    Integer.parseInt(JOptionPane.showInputDialog("Ingrese el nuevo id")));
                                            break;
                                        case 0:
                                            break;
                                        default:
                                            JOptionPane.showMessageDialog(null, "ERROR: opcion no valida");
                                            break;
                                    }
                                    if (resp == -1) {
                                        JOptionPane.showMessageDialog(null, "ADVERTENCIA: arreglo de objetos vacio");
                                    } else if (resp == -2) {
                                        JOptionPane.showMessageDialog(null, "Animal no encontrado");
                                    } else {
                                        JOptionPane.showMessageDialog(null, "Modificacion realizada con exito");
                                    }
                                }
                                //siempre hay que volver a index al valor de la opcion del menu princial seleccionada en este caso 1
                                index = 2;
                                break;
                            case 3:
                                JOptionPane.showMessageDialog(null, registroAnimales.getAnimal(Integer.parseInt(JOptionPane.showInputDialog("Ingrese el id del animal a buscar"))));
                                break;
                            case 4:
                                JOptionPane.showMessageDialog(null, registroAnimales);
                                break;
                            case 5:
                                index = registroAnimales.eliminar(Integer.parseInt(JOptionPane.showInputDialog("Ingrese el id del animal a eliminar")));
                                if (index == -1) {
                                    JOptionPane.showMessageDialog(null, "ADVERTENCIA: arreglo de objetos vacio");
                                } else if (index == -2) {
                                    JOptionPane.showMessageDialog(null, "Animal no encontrado");
                                } else {
                                    JOptionPane.showMessageDialog(null, "Modificacion realizada con exito");
                                }
                                break;
                            case 0:
                                break;
                            default:
                                ;
                                break;
                        }
                    }
                    //siempre hay que volver a index al valor de la opcion del menu princial seleccionada en este caso 1
                    index = 1;
                    break;
                case 2:
                    JOptionPane.showMessageDialog(null, "ADVERTENCIA: Funcionalidad en desarrollo");
                    break;
                case 3:
                    JOptionPane.showMessageDialog(null, "ADVERTENCIA: Funcionalidad en desarrollo");
                    break;
                case 4:
                    JOptionPane.showMessageDialog(null, "ADVERTENCIA: Funcionalidad en desarrollo");
                    break;
                case 5:
                    Animal aux = registroAnimales.getAnimal(Integer.parseInt(JOptionPane.showInputDialog(registroAnimales + "\nIngrese el id del animal a buscar")));
                    if (aux != null) {
                        JOptionPane.showMessageDialog(null, aux.gestionAlimentacion());
                    } else {
                        JOptionPane.showMessageDialog(null, "Animal no encontrado");
                    }
                    break;
                case 6:
                    JOptionPane.showMessageDialog(null, "ADVERTENCIA: Funcionalidad en desarrollo");
                    break;
                case 0:
                    JOptionPane.showMessageDialog(null, "Finalizando el programa");
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "ERROR: opcion no valida");
                    break;
            }

        } while (index != 0);

    }

}
