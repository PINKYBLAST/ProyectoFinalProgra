/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectozoo;

/**
 *
 * @author Pepe Le Pew
 */
public class RegistroAnimales {
    private Animal arregloAnimales[]=new Animal[50];
    private int cantAnimales=0;

    public RegistroAnimales() { 
        this.arregloAnimales[0]=new Animal("Animal1","Lobo","Carne","Diurno","1 vez al dia","Busque de montanna",4,1);
        this.arregloAnimales[1]=new Animal("Animal2","Leon","Carne","Diurno","2 veces al dia","Bosque seco",3,2);
        this.arregloAnimales[2]=new Animal("Animal3","Tibre","Carne","Diurno","1 vez al dia","Selva tropical",6,3);
        this.arregloAnimales[3]=new Animal("Animal4","Pantera","Carne","Diurno","2 veces al dia","Busque de montanna",7,4);
        this.cantAnimales=4; // si agregan o eliminan mas datos precargados deben modifiar este valor
    
    }
    
    public boolean agregar(Animal animal){
        if(cantAnimales<this.arregloAnimales.length){
            for (int i=0;i<this.arregloAnimales.length;i++){
                if(this.arregloAnimales[i]==null){
                    //Creo y almaceno el obj en el arreglo
                    this.arregloAnimales[i]=animal;
                    this.cantAnimales=cantAnimales+1;
                    break;
                }
            }
            return true;
        }else{
            return false;
        }
    }
    
    //Si se cambia por #animal debe modificar el porque elimina
    public int eliminar(int id){
        if(cantAnimales>0){
            for (int i=0;i<this.arregloAnimales.length;i++){
                if(this.arregloAnimales[i]!=null&&this.arregloAnimales[i].getId()==id){
                    //Creo y almaceno el obj en el arreglo
                    this.arregloAnimales[i]=null;
                    this.cantAnimales=cantAnimales-1;
                    return 1;
                }
            }
            return -2;
        }else{
            return -1;
        }
    }
    
    //Si se cambia por #animal debe modificar el porque modifica 
    public int modificaEdad(int id, int edad){
        if(cantAnimales>0){
            for (int i=0;i<this.arregloAnimales.length;i++){
                if(this.arregloAnimales[i]!=null&&this.arregloAnimales[i].getId()==id){
                    //Creo y almaceno el obj en el arreglo
                    this.arregloAnimales[i].setEdad(edad);
                    return 1;
                }
            }
            return -2;
        }else{
            return -1;
        }
    }
    
    //Despues debe ser modificada por un obj de tipo habitad
    public int modificaHabitat(int id, String habitat){
        if(cantAnimales>0){
            for (int i=0;i<this.arregloAnimales.length;i++){
                if(this.arregloAnimales[i]!=null&&this.arregloAnimales[i].getId()==id){
                    //Creo y almaceno el obj en el arreglo
                    this.arregloAnimales[i].setHabitat(habitat);
                    return 1;
                }
            }
            return -2;
        }else{
            return -1;
        }
    }
    
    public int modificaFrecAl(int id, String frecAlimento){
        if(cantAnimales>0){
            for (int i=0;i<this.arregloAnimales.length;i++){
                if(this.arregloAnimales[i]!=null&&this.arregloAnimales[i].getId()==id){
                    //Creo y almaceno el obj en el arreglo
                    this.arregloAnimales[i].setFrecAlimento(frecAlimento);
                    return 1;
                }
            }
            return -2;
        }else{
            return -1;
        }
    }
    
    public int modificaHorario(int id, String horario){
        if(cantAnimales>0){
            for (int i=0;i<this.arregloAnimales.length;i++){
                if(this.arregloAnimales[i]!=null&&this.arregloAnimales[i].getId()==id){
                    //Creo y almaceno el obj en el arreglo
                    this.arregloAnimales[i].setHorario(horario);
                    return 1;
                }
            }
            return -2;
        }else{
            return -1;
        }
    }
    
    public int modificaAlimento(int id, String alimento){
        if(cantAnimales>0){
            for (int i=0;i<this.arregloAnimales.length;i++){
                if(this.arregloAnimales[i]!=null&&this.arregloAnimales[i].getId()==id){
                    //Creo y almaceno el obj en el arreglo
                    this.arregloAnimales[i].setAlimento(alimento);
                    return 1;
                }
            }
            return -2;
        }else{
            return -1;
        }
    }
    
    public int modificaEspecie(int id, String especie){
        if(cantAnimales>0){
            for (int i=0;i<this.arregloAnimales.length;i++){
                if(this.arregloAnimales[i]!=null&&this.arregloAnimales[i].getId()==id){
                    //Creo y almaceno el obj en el arreglo
                    this.arregloAnimales[i].setEspecie(especie);
                    return 1;
                }
            }
            return -2;
        }else{
            return -1;
        }
    }
    
    public int modificaNombre(int id, String nombre){
        if(cantAnimales>0){
            for (int i=0;i<this.arregloAnimales.length;i++){
                if(this.arregloAnimales[i]!=null&&this.arregloAnimales[i].getId()==id){
                    //Creo y almaceno el obj en el arreglo
                    this.arregloAnimales[i].setNombre(nombre);
                    return 1;
                }
            }
            return -2;
        }else{
            return -1;
        }
    }
    
    //Si se cambia por #animal debe modificar el porque modifica
    public int modificaId(int id, int nuevoId){
        if(cantAnimales>0){
            for (int i=0;i<this.arregloAnimales.length;i++){
                if(this.arregloAnimales[i]!=null&&this.arregloAnimales[i].getId()==id){
                    //Creo y almaceno el obj en el arreglo
                    this.arregloAnimales[i].setId(nuevoId);
                    return 1;
                }
            }
            return -2;
        }else{
            return -1;
        }
    }

    public Animal[] getArregloAnimales() {
        return arregloAnimales;
    }
    
    public Animal getAnimal(int id) {
        if(cantAnimales>0){
            for (int i=0;i<this.arregloAnimales.length;i++){
                if(this.arregloAnimales[i]!=null&&this.arregloAnimales[i].getId()==id){
                    //Creo y almaceno el obj en el arreglo
                    return this.arregloAnimales[i];
                }
            }
            return null;
        }else{
            return null;
        }
    }
    
    @Override
    public String toString(){
        String r="";
        if(cantAnimales>0){
            for (int i=0;i<this.arregloAnimales.length;i++){
                if(this.arregloAnimales[i]!=null){r+=arregloAnimales[i]+"\n";}
            }
        }else{
            r="Vacio";
        }
        return r;
    }
    
}
